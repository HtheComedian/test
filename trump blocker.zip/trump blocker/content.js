(function () {
  const keywords = ["Trump"];
  const matched = keywords.some((keyword) => pageText.includes(keyword));

  if (matched) {
    window.location.href = "www.Lateflix.com";
  }
})();
